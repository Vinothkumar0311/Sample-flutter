import '../Screen/table.dart';
import '../Screen/mapList2.dart';
import '../services/inputpass.dart';
import 'package:task/map_value.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

// ignore_for_file: use_build_context_synchronously

class InputField extends StatefulWidget {
  const InputField({super.key});

  @override
  State<InputField> createState() => _InputField();
}

class _InputField extends State<InputField> {
  List<UserInput> _userList = [];
  final _userServicesList = UserService();
  int dulplicateValue = 0;

  readValueTable() async {
    var value = await _userServicesList.readAllUsers();
    _userList = <UserInput>[];
    value.forEach((userValue) {
      setState(() {
        var userValuelist = UserInput();
        userValuelist.firstName = userValue['firstName'];
        userValuelist.lastName = userValue['lastName'];
        userValuelist.emailid = userValue['emailid'];
        userValuelist.mobileNumber = userValue['mobileNumber'];
        _userList.add(userValuelist);
      });
    });
    print('input field list length check');
    print(_userList.toList());
  }

  @override
  void initState() {
    readValueTable();
    super.initState();
  }

  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final emailidController = TextEditingController();
  final mobileNumberController = TextEditingController();
  final _userService = UserService();

  addTask() async {
    if (firstNameController.text.trim().isEmpty ||
        lastNameController.text.trim().isEmpty ||
        emailidController.text.trim().isEmpty ||
        mobileNumberController.text.trim().isEmpty) {
      Fluttertoast.showToast(
        msg: 'Field is Empty',
        gravity: ToastGravity.CENTER,
        fontSize: 25,
        backgroundColor: Colors.red,
      );
    } else {
      for (int i = 0; i < _userList.length; i++) {
        if (_userList[i]
                .firstName!
                .toLowerCase()
                .contains(firstNameController.text) ||
            _userList[i]
                .lastName!
                .toLowerCase()
                .contains(lastNameController.text) ||
            _userList[i]
                .emailid!
                .toLowerCase()
                .contains(emailidController.text) ||
            _userList[i]
                .mobileNumber!
                .toLowerCase()
                .contains(mobileNumberController.text)) {
          dulplicateValue = 1;
          Fluttertoast.showToast(
            msg: 'some value are already entered',
            gravity: ToastGravity.CENTER,
            fontSize: 25,
            backgroundColor: Colors.red,
          );
        } else {
          dulplicateValue = 0;
        }
      }
    }
    if (dulplicateValue == 0) {
      var user = UserInput();
      user.firstName = firstNameController.text;
      user.lastName = lastNameController.text;
      user.emailid = emailidController.text;
      user.mobileNumber = mobileNumberController.text;
      await _userService.SaveUser(user);
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (BuildContext context) {
        return const ListMapValues();
      }));
      firstNameController.text = '';
      lastNameController.text = '';
      emailidController.text = '';
      mobileNumberController.text = '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('InputField'), centerTitle: true),
        body: Column(
          // mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.only(left: 45, top: 30, right: 45),
              child: TextField(
                controller: firstNameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  labelText: 'FirstName',
                  labelStyle:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  hintStyle: TextStyle(fontSize: 16),
                  hintText: '',
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp("[a-zA-Z]"))
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 45, top: 10, right: 45),
              child: TextField(
                controller: lastNameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  labelText: 'LastName',
                  labelStyle:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  hintStyle: TextStyle(fontSize: 16),
                  hintText: '',
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp("[a-zA-Z]"))
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 45, top: 10, right: 45),
              child: TextField(
                controller: emailidController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  labelText: 'Emailid',
                  labelStyle:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  hintStyle: TextStyle(fontSize: 16),
                  hintText: '',
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 45, top: 10, right: 45),
              child: TextField(
                controller: mobileNumberController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  labelText: 'MobileNumber',
                  labelStyle:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  hintStyle: TextStyle(fontSize: 16),
                  hintText: '',
                  counter: null,
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                maxLength: 10,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    addTask();
                  },
                  child: const Text('Submit'),
                ),
                const SizedBox(
                  width: 5,
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                      return const ListMapValues();
                    }));
                  },
                  child: const Text('View Value'),
                ),
                const SizedBox(
                  width: 5,
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                      return const ViewTable();
                    }));
                  },
                  child: const Text('View table'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
